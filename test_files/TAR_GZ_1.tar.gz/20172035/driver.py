#!/usr/bin/python

import smtplib
import imaplib

def readmail(person,passwd,current_mails):
	try:
		mail=imaplib.IMAP4_SSL('imap.hushmail.com',993)
		mail.login(person,passwd)
		while(1):
			mail.list()#it will store all the folder names
			mail.select('inbox')
			result,data=mail.search(None,'ALL')
			#result = OK , we can check for result == "OK"
			ids=data[0]#data is a list having ids of all mails ['1 2 3 4 ... n']
					   #data[0] is a space seperated string
			id_list=ids.split()
			total_mails_in_inbox=len(id_list)
			if total_mails_in_inbox>current_mails:
				latest_mail=id_list[-1]#id=1(oldest mail) and id=n(latest mail)
				result,data=mail.fetch(latest_mail,"(RFC822)")
				raw_mail=data[0][1]
				return raw_mail
	except Exception:
		print 'Error in reading mail !'
		exit(0)


def sum(data):
	s=0
	for i in data:
		s=s+int(i)
	return s



def skeleton(sender,s_passwd,receiver,r_passwd,current_mails):
	r=readmail(receiver,r_passwd,current_mails)
	
	print '**************************'
	print '*Skeleton received data !*'
	print '**************************\n'

	############# demarshalling ##################
	l=len(r)
	pos1=r.find("#@#")
	for i in xrange(pos1+3,l):
		if(r[i] == "#"):
			pos2=i
			break
	data=r[pos1+3:pos2].split()#list containing numbers

	##############################################
	s=sum(data)
	try:
		session=smtplib.SMTP('smtp.hushmail.com',587)
		session.starttls()

		######## Marshalling #########
		result="#@#"+str(s)+"#@#"
		##############################

		msg="""From: <"""+receiver+""">\nTo: <"""+sender+""">\nMIME-Version: 1.0\nContent-type: text/html\nSubject: Sending param\n"""+result

		session.login(receiver,r_passwd)
		session.sendmail(receiver,sender,msg)

		print '************************'
		print '*Skeleton sent output !*'
		print '************************\n'

		session.quit()
	except Exception:
		print 'Error in sending mail !'
		exit(0)



def local_sum(nos):
	try:
		session=smtplib.SMTP('smtp.hushmail.com',587)
		session.starttls()

		sender='sgoyal@hushmail.com'
		receiver='cgoyal@hushmail.com'
		s_passwd='chunugoyal'
		r_passwd='chunugoyal'
		
		####### Marshalling ########
		nos="#@#"+nos+"#@#"
		############################

		msg="""From: <"""+sender+""">\nTo: <"""+receiver+""">\nMIME-Version: 1.0\nContent-type: text/html\nSubject: Sending param\n"""+nos

		#### Checking current mails of the sender ####
		try:
			mmail1=imaplib.IMAP4_SSL('imap.hushmail.com',993)#imap only :) not smtp
			mmail1.login(sender,s_passwd)
			mmail1.list()#it will store all the folder names
			mmail1.select('inbox')
			tresult1,tdata1=mmail1.search(None,'ALL')
			tids1=tdata1[0]
			tid_list1=tids1.split()

			sender_current_mails1=len(tid_list1)

			#################################################


			session.login(sender,s_passwd)


			#### Checking current mails of the receiver ####

			mmail=imaplib.IMAP4_SSL('imap.hushmail.com',993)#imap only :) not smtp
			mmail.login(receiver,r_passwd)
			mmail.list()#it will store all the folder names
			mmail.select('inbox')
			tresult,tdata=mmail.search(None,'ALL')
			tids=tdata[0]
			tid_list=tids.split()

			current_mails=len(tid_list)
		except Exception:
			print 'Error in reading mail !'
			exit(0)

		################################################

		session.sendmail(sender,receiver,msg)
		print '******************'
		print '*Stub sent data !*'
		print '******************\n'
		session.quit()


		######## invoking skeleton #########
		skeleton(sender,s_passwd,receiver,r_passwd,current_mails)
		####################################

		s=readmail(sender,s_passwd,sender_current_mails1)#reading answer from the mail server

		print '*************************'
		print '*Stub received results !*'
		print '*************************\n'
		
		##### Demarshalling #####
		l=len(s)
		pos1=s.find("#@#")
		lis=[]
		for i in xrange(pos1+3,l):
			if(s[i] == "#"):
				pos2=i
				break
		res=s[pos1+3:pos2].split()#list containing numbers
		#########################

		return int(res[0])
	except Exception:
		print 'Error in sending mail !'
		exit(0)

n=int(raw_input('Enter the no. of parameters: '))
print 'Enter ',n,' parameters to add(seperated by space): '
nos=raw_input()
temp=nos.split()
try:
	for i in temp:
		int(i)
except Exception:
	print 'Type Error: You must give all integers !'
	exit(0)


s=local_sum(nos)
print 'Sum =',s