#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
	FILE *fp;
	fp=fopen("1000_float_points.txt","w");
	fprintf(fp,"1000\n");

    srand((int)time(NULL));


    float a = 100.0,x,y;

    for (int i=0;i<1000;i++)
    {
    	x=((float)rand()/(float)(RAND_MAX)) * a;
        printf("%0.3f\n", x);
    	y=((float)rand()/(float)(RAND_MAX)) * a;
        printf("%0.3f\n", y);
        if(i==999)
	        fprintf(fp,"%0.3f %0.3f",x,y);
	    else
			fprintf(fp,"%0.3f %0.3f\n",x,y);	    	
    }
    return 0;
}