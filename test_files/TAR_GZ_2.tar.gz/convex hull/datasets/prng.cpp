#include <stdio.h>      /* printf, scanf, puts, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

int main ()
{
  int i;
  int x,y;
  /* initialize random seed: */
  srand (time(NULL));

  FILE *fp;
  fp=fopen("100000_int_points.txt","w");
  fprintf(fp,"100000\n");

  for(i=0;i<100000;i++)
  {
    x = rand() % 10 + -5;
    printf("%d ",x);
    y = rand() % 10 + -5;
    printf("%d",y);
    printf("\n");
    if(i == 99999)
      fprintf(fp,"%d %d",x,y);
    else
      fprintf(fp,"%d %d\n",x,y);
  }

  fclose(fp);
  return 0;
}