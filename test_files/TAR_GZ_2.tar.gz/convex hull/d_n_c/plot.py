import numpy as np
import matplotlib.pyplot as plt

f=open('hull_points.csv','r')
l=(f.read()).split('\n')
f.close()
x=[]
y=[]

for i in l:
	t=i.split(',')
	x.append(int(t[0]))
	y.append(int(t[1]))



N=np.size(x)
P = np.array([(x[i],y[i]) for i in range(N)])

L = P

plt.figure()
plt.plot(L[:,0],L[:,1], 'b-', picker=5)
plt.plot([L[-1,0],L[0,0]],[L[-1,1],L[0,1]], 'b-', picker=5)
plt.plot(P[:,0],P[:,1],".r")
plt.axis('off')
plt.show()





# t1 = np.arange(0.0, 5.0, 0.1)
# t2 = np.arange(0.0, 5.0, 0.02)

# t1 = np.asarray(y);
# t2 = np.asarray(x);

# plt.figure(1)
# plt.plot(t1, 'bo', t2, 'k')
# plt.show()