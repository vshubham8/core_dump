#include<bits/stdc++.h>
using namespace std;
 
pair<int, int> mid;
 
int orientation(pair<int, int> a, pair<int, int> b, pair<int, int> c)
{
    int res = (b.second-a.second)*(c.first-b.first) - (c.second-b.second)*(b.first-a.first);
 
    if (res == 0)
        return 0;
    if (res > 0)
        return 1;
    return -1;
}
 
bool compare(pair<int, int> p1, pair<int, int> q1)
{
    pair<int, int> p = make_pair(p1.first - mid.first,
        p1.second - mid.second);
    pair<int, int> q = make_pair(q1.first - mid.first,
        q1.second - mid.second);
 
    int one,two;
    if (p.first >= 0 && p.second >= 0)
        one=1;
    if (p.first <= 0 && p.second >= 0)
        one=2;
    if (p.first <= 0 && p.second <= 0)
        one=3;
    if(p.first >= 0 && p.second <= 0)
        one=4;

    if (q.first >= 0 && q.second >= 0)
        two=1;
    if (q.first <= 0 && q.second >= 0)
        two=2;
    if (q.first <= 0 && q.second <= 0)
        two=3;
    if(q.first >= 0 && q.second <= 0)
        two=4;
 
    if (one != two)
        return (one < two);
    return (p.second*q.first < q.second*p.first);
}
 
vector<pair<int, int> > merge_small_hulls(vector<pair<int, int> > a, vector<pair<int, int> > b)
{
    int n1 = a.size(), n2 = b.size();
 
    int ia = 0, ib = 0;
    for (int i=1; i<n1; i++)
        if (a[i].first > a[ia].first)
            ia = i;
    for (int i=1; i<n2; i++)
        if (b[i].first < b[ib].first)
            ib=i;
    int inda = ia, indb = ib;
    bool done = 0;
    while (!done)
    {
        done = 1;
        while (orientation(b[indb], a[inda], a[(inda+1)%n1]) >=0)
            inda = (inda + 1) % n1;
 
        while (orientation(a[inda], b[indb], b[(n2+indb-1)%n2]) <=0)
        {
            indb = (n2+indb-1)%n2;
            done = 0;
        }
    }
 
    int uppera = inda, upperb = indb;
    inda = ia, indb=ib;
    done = 0;
    int g = 0;
    while (!done)
    {
        done = 1;
        while (orientation(a[inda], b[indb], b[(indb+1)%n2])>=0)
            indb=(indb+1)%n2;
 
        while (orientation(b[indb], a[inda], a[(n1+inda-1)%n1])<=0)
        {
            inda=(n1+inda-1)%n1;
            done=0;
        }
    }
 
    int lowera = inda, lowerb = indb;
    vector<pair<int, int> > ret;

    int ind = uppera;
    ret.push_back(a[uppera]);
    while (ind != lowera)
    {
        ind = (ind+1)%n1;
        ret.push_back(a[ind]);
    }
 
    ind = lowerb;
    ret.push_back(b[lowerb]);
    while (ind != upperb)
    {
        ind = (ind+1)%n2;
        ret.push_back(b[ind]);
    }
    return ret;
 
}
 
vector<pair<int, int> > small_hull_solver(vector<pair<int, int> > a)
{

    set<pair<int, int> >s;
 
    for (int i=0; i<a.size(); i++)
    {
        for (int j=i+1; j<a.size(); j++)
        {
            int x1 = a[i].first, x2 = a[j].first;
            int y1 = a[i].second, y2 = a[j].second;
 
            int a1 = y1-y2;
            int b1 = x2-x1;
            int c1 = x1*y2-y1*x2;
            int pos = 0, neg = 0;
            for (int k=0; k<a.size(); k++)
            {
                if (a1*a[k].first+b1*a[k].second+c1 <= 0)
                    neg++;
                if (a1*a[k].first+b1*a[k].second+c1 >= 0)
                    pos++;
            }
            if (pos == a.size() || neg == a.size())
            {
                s.insert(a[i]);
                s.insert(a[j]);
            }
        }
    }
 
    vector<pair<int, int> >ret;

    set<pair<int,int> >::iterator it;
    for(it=s.begin();it != s.end();it++)
        ret.push_back(*it);

    mid.first=mid.second=0;
    int n = ret.size();
    for (int i=0; i<n; i++)
    {
        mid.first += ret[i].first;
        mid.second += ret[i].second;
        ret[i].first *= n;
        ret[i].second *= n;
    }
    sort(ret.begin(), ret.end(), compare);
    for (int i=0; i<n; i++)
        ret[i] = make_pair(ret[i].first/n, ret[i].second/n);
 
    return ret;
}
 
vector<pair<int, int> > divide_and_conquer(vector<pair<int, int> > a)
{
    if (a.size() <= 5)
        return small_hull_solver(a);
    vector<pair<int, int> >left, right;
    for (int i=0; i<a.size()/2; i++)
        left.push_back(a[i]);
    for (int i=a.size()/2; i<a.size(); i++)
        right.push_back(a[i]);

    vector<pair<int, int> >left_hull = divide_and_conquer(left);
    vector<pair<int, int> >right_hull = divide_and_conquer(right);

    return merge_small_hulls(left_hull, right_hull);
}

int main(int argc, char *argv[])
{
    FILE *fp;
	if(argc != 2)
	{
		printf("Wrong input !!!\nTry again - Usuage:\n\t %s filename(of dataset)",argv[0]);
	}
	else
	{

    	fp=fopen(argv[1],"r");
    	if(!fp)
    	{
    		cout<<"Couldn't open the file !!!"<<endl;
    		cout<<"Try again !!!"<<endl;
    		exit(1);
    	}
	}


    int n,i,x,y;
    pair<int,int> pyara;
    vector<pair<int, int> > a;


    fscanf(fp,"%d",&n);
    do
    {
       fscanf(fp,"%d %d", &x, &y);
        pyara = make_pair(x,y);
        a.push_back(pyara);
        cout<<"pushing "<<++sno<<" point...\n";
    }
    while(!feof(fp));

    fclose(fp);

    cout<<"All points pushed...\n";


//    printf("\n\ncount = %d \n",c);


    // cout<<"Enter the number of points: "<<endl;
    // cin>>n;

    // for(i=0;i<n;i++)
    // {
    //     cin>>x>>y;
    //     pyara = make_pair(x,y);
    //     a.push_back(pyara);
    // }

    sort(a.begin(), a.end());
    cout<<"Points sorted !!!\n";
    vector<pair<int,int> >ans = divide_and_conquer(a);
    vector<pair<int,int> >::iterator it;
 
//    cout << "Convex hull for the given points:\n";

    FILE *fp1 = fopen("hull_points.csv","w");
    for(it=ans.begin();it != ans.end();it++)
    {
    	if(it == ans.end()-1)
	    	fprintf(fp1,"%d,%d",(*it).first,(*it).second);
	    else
	    	fprintf(fp1,"%d,%d\n",(*it).first,(*it).second);

//        cout<<(*it).first<<" "<<(*it).second<<endl;
    }
    fclose(fp1);

 
    return 0;
}