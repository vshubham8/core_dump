#include <bits/stdc++.h>
using namespace std;

pair<int, int> mid;

int tang_oreint(pair<int, int> a,pair<int, int> b,pair<int, int> c)
{
	int r = (((c.first-b.first)*(b.second-a.second))-((b.first-a.first)*(c.second-b.second)));
	
	if(r==0)
		return 0;
	if(r>0)
		return 1;
	else
		return -1;			
}

//function to merge

vector<pair<int, int> > convex_hull_merge(vector<pair<int, int> > a,vector<pair<int, int> > b)
{
	int n1 = a.size();//points in a
	int n2 = b.size();//points in b
	int ia=0;
	int ib=0;

	for(int i=1;i<n1;i++)
	{
		if(a[i].first > a[ia].first)
			ia = i;
		//rightmost point
	}

	for(int i=1;i<n2;i++)
	{
		if(b[i].first < b[ib].first)
			ib=i;
		//leftmost point
	}

	//upper tangent
	int inda = ia, indb = ib;
	bool done = 0;
	while(!done)
	{
		done=1;
		while(tang_oreint(b[indb],a[inda],a[(inda+1)%n1]) >=0 )
			inda = (inda+1)%n1;

		while(tang_oreint(a[inda],b[indb],b[(indb+n2-1)%n2]) <=0 )
		{
			indb = (indb+n2-1)%n2;
			done=0;
		}
	}


	int upperA = inda;
	int upperB = indb;

	//lower tangent
	inda = ia, indb = ib;
	done = 0;
	while(!done)
	{
		done=1;
		while(tang_oreint(a[inda],b[indb],b[(indb+1)%n2]) >= 0)
			indb = (indb+1)%n2;

		while(tang_oreint(b[indb],a[inda],a[(inda+n1-1)%n1]) <= 0)
		{
			inda = (inda+n1-1)%n1;
			done=0;
		}
	}

	int lowerA = inda;
	int lowerB = indb;

	vector<pair<int, int> > returnn;
//returnn contains convex hull after merging anti-clockwise

	int id = upperA;
	returnn.push_back(a[upperA]);
	while(id!=lowerA)
	{
		id=(id+1)%n1;
		returnn.push_back(a[id]);	
	}
	id = lowerB;
	returnn.push_back(b[lowerB]);
	while(id!=upperB)
	{
		id=(id+1)%n2;
		returnn.push_back(b[id]);	
	}

	return returnn;



}


//compare function for sorting

bool compare_function(pair<int, int> p1,pair<int, int> q1)
{
	pair<int, int> p = make_pair(p1.first-mid.first,p1.second-mid.second);
	pair<int, int> q = make_pair(q1.first-mid.first,q1.second-mid.second);

	//determine quadrant

	int one;

	if(p.first>=0 && p.second>=0)
		one=1;
	if(p.first<=0 && p.second>=0)
		one=2;
	if(p.first<=0 && p.second<=0)
		one=3;
	else
		one=4;

	int two;

	if(q.first>=0 && q.second>=0)
		two=1;
	if(q.first<=0 && q.second>=0)
		two=2;
	if(q.first<=0 && q.second<=0)
		two=3;
	else
		two=4;

	

	if(one!=two)
		return (one<two);

	return (p.second*q.first < q.second*p.first);		




}



//brute function if size <= 5

vector<pair<int, int> > bruteHull(vector<pair<int, int> > a)
{

	set<pair<int, int> >s;
	for(int i=0;i<a.size();i++)
	{
		for(int j=i+1;j<a.size();j++)
		{
			int x1=a[i].first;
			int y1=a[i].second;
			int x2=a[j].first;
			int y2=a[j].second;

			int a1=y1-y2;
			int b1=x2-x1;
			int c1=x1*y2-y1*x2;

			int pos=0,neg=0;

			for(int k=0;k<a.size();k++)
			{
				if(a1*a[k].first+b1*a[k].second+c1<=0)
					neg++;
				if(a1*a[k].first+b1*a[k].second+c1>=0)
					pos++;
			}

			if(pos==a.size()||neg==a.size())
			{
				s.insert(a[i]);
				s.insert(a[j]);
			}


		}
	}

	vector<pair<int, int> > returnn;
	set<pair<int, int> >::iterator it;
//	for(auto e:s)
//		returnn.push_back(e);
	for(it=s.begin();it!=s.end();it++)
		returnn.push_back(*it);

	//sort points anti clockwise

	mid.first=mid.second=0;
	int n=returnn.size();
	for(int i=0;i<n;i++)
	{
		mid.first=mid.first+returnn[i].first;
		mid.second=mid.second+returnn[i].second;
		returnn[i].first=returnn[i].first*n;
		returnn[i].second=returnn[i].second*n;
	}

	sort(returnn.begin(),returnn.end(),compare_function);

	for(int i=0;i<n;i++)
		returnn[i]=make_pair(returnn[i].first/n,returnn[i].second/n);

	return returnn;


}



//divide function in divide and conquer
vector<pair<int, int> > convex_hull_divide(vector<pair<int, int> > a)
{
	if(a.size() <= 5)
		return bruteHull(a);

	vector<pair<int, int> > left;

	for(int i=0;i<a.size()/2;i++)
		left.push_back(a[i]);

	vector<pair<int, int> > left_hull = convex_hull_divide(left);

	vector<pair<int, int> > right;

	for(int i=a.size()/2;i<a.size();i++)
		right.push_back(a[i]);

	vector<pair<int, int> > right_hull = convex_hull_divide(right);

	return convex_hull_merge(left_hull,right_hull);
}


int main()
{
	int n;
	cin>>n;
	int x,y;
	vector<pair<int,int> > a;

	while(n--)
	{
		cin >> x;
		cin >> y;
		a.push_back(make_pair(x,y));
	}

	sort(a.begin(),a.end());

	vector<pair<int,int> > answer = convex_hull_divide(a);
	vector<pair<int,int> >::iterator it;
	cout<<"Convex Hull for the given points:"<<endl;
	for(it=answer.begin();it!=answer.end();it++)
		cout<<(*it).first<<" "<<(*it).second<<endl;	

return 0;
}