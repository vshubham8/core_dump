#I am not getting how to write this bash script file as I am taking command line argument in python file.
#Please run my_sql.py with commandline argument