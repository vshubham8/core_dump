import sqlparse
import sys

#sys.stdout.write()

#{{[]}} - DDL
all_tables={}
all_tables_indexed={}
aggregate_functions = ['max','min','sum','avg']

def cap(rel1,table2_name):
	rel=[]
	rel2=[]
	product = open(table2_name+'.csv','r').read().split()
	attributes = all_tables_indexed[table2_name].values()
	s=''
	for i in xrange(0,len(attributes)):
		if i == len(attributes)-1:
			s=s+table2_name+'.'+attributes[i]
		else:
			s=s+table2_name+'.'+attributes[i]+','
	rel2.append(s)
	rel2.extend(product)


	rel.append(rel1[0]+'|'+s)
	for i in xrange(0,len(rel1)-1):
		for j in xrange(0,len(rel2)-1):
			rel.append(rel1[1::][i]+'|'+rel2[1::][j])

	return rel





def select_all(tables,cartesian_product,conditions):
	if conditions == '':
		if len(tables) == 1:
			attributes = all_tables_indexed[tables[0]].values()
			s=''
			for i in xrange(0,len(attributes)):
				if i == len(attributes)-1:
					s=s+tables[0]+'.'+attributes[i]
#					print tables[0]+'.'+attributes[i]
				else:
					s=s+tables[0]+'.'+attributes[i]+','
#					print tables[0]+'.'+attributes[i]+',',
			print s
			for i in cartesian_product[1::]:
				print i
		else:
			for i in cartesian_product:
				print i
	else:
		sab_conditions = []
		extras=[]
		for i in conditions[2:]:
			s = str(i)
			if s != 'AND' and s!=' ':
				sab_conditions.append(s)
			else:
				extras.append(s)
		# print 'conditions: ',sab_conditions
		if len(tables) == 1:
			attrib=[]
			for i in sab_conditions:
				attrib.append(i[0])
			# print 'Attributes: ',attrib
			indi=[]
			# print 'Product: ',cartesian_product
			indices=all_tables_indexed[tables[0]].values()
			for j in attrib:
				for i in xrange(0,len(indices)):
					if indices[i] == j:
						indi.append(i)
			# print 'Indices: ',indi
			data=cartesian_product[1:]
			# for i in data:	
			# 	print i
			filtered=[]
			operator=[]
			operands=[]
			for i in sab_conditions:
				if i[1] == '=':
					operator.append('==')
				elif i[1] == '<':
					operator.append('<')
				elif i[1] == '>':
					operator.append('>')
				elif i[1] == '<=':
					operator.append('<=')
				elif i[1] == '>=':
					operator.append('>=')
				operands.append(i[-1])
			# print operator
			# print operands
			# b=bool(data[1][0]+operator[0]+operands[0])
			# print b

			junctions=[]
			for i in xrange(0,len(extras)):
				if extras[i] != ' ':
					junctions.append(extras[i])

			# print junctions


			#### OR implemented ####
			if(junctions==[]):
				for i in xrange(0,len(operator)):
					if operator[i] == '==':
						for j in xrange(0,len(indi)):
							for k in xrange(0,len(data)):
								if data[k][j] == operands[j]:
									filtered.append(data[k])
			elif junctions[0] == 'AND':
				for i in xrange(0,len(operator)):
					if operator[i] == '==':
						for j in xrange(0,len(indi)):
							for k in xrange(0,len(data)):
								if data[k][j] == operands[j]:
									filtered.append(data[k])

			# print filtered
			#### removing duplicates ####
			D=set(filtered)
			ind=[]
			for i in D:
				ind.append(filtered.index(i))
			ind.sort()
			distinct_values=[]
			for i in ind:
				distinct_values.append(filtered[i])
			for i in distinct_values:
				print i
			####### match the value and display accordingly #######
		else:
			print cartesian_product[0]


def select(col_names,tables,cartesian_product,conditions):
	if conditions == '':
		if len(tables) == 1:
			L=[]
			indices=[]
			temp = cartesian_product[0].split(',')
			attrib = col_names
			# print attrib
			# print temp

			if(len(attrib)>len(temp)):
				print 'More attributes selected...'
				return
			else:
	
				for i in attrib:
					if i not in temp:
						print 'Wrong attributes entered...'
						return

				for j in col_names:
					for i in xrange(0,len(temp)):
						if j == temp[i]:
							indices.append(i)
							break
				data=[]
				for i in cartesian_product[1::]:
					data.append(i.split(','))

				s=''
				for i in xrange(0,len(col_names)):
					s=s+tables[0]+'.'+col_names[i]
					if i != len(col_names)-1:
						s=s+','
				s=s+'\n'
				for i in xrange(0,len(data)):
					for j in xrange(0,len(indices)):
						if j == len(indices)-1:
							s=s+data[i][indices[j]]
						else:
							s=s+data[i][indices[j]]+','
					s=s+'\n'
				print s[0:len(s)-1]
		else:
			L=[]
			indices=[]
			temp = cartesian_product[0].split(',')
			attrib = col_names
			# print attrib
			# print temp

			# print cartesian_product
			new_tables=[]
			new_attrib=[]
			for i in attrib:
				new_tables.append(i[0:len(i)-2])
				new_attrib.append(i[-1])
			# print new_tables
			# print new_attrib
			L=[]

			for j in xrange(0,len(attrib)):
				# print attrib[j]
				table_name = attrib[j].split('.')[0]
				# print table_name
				attrib_name = attrib[j].split('.')[-1]
				# print attrib_name
				table_index = attrib[j].split('.')[0][-1]
				# print table_index
				cc = []
				for k in cartesian_product:
					cc.append(k.split('|'))
				# print cc

				indi=[]
				ll_v = all_tables_indexed[table_name].values()
				for k in xrange(0,len(attrib_name)):
					for m in xrange(0,len(ll_v)):
						if attrib_name[k] == ll_v[m]:
							indi.append(m)
							break
				# print indi
				# print cc
				l=[]
				for k in xrange(0,len(cc)):
					# print cc[k][int(table_index)-1]
					tt = cc[k][int(table_index)-1]# each row
					tt=tt.split(',')
					# print tt[indi[0]]
					l.append(tt[indi[0]])
				L.append(l)
			# print L
			s=''
			p=0
			for i in xrange(0,len(L[0])):
				for j in xrange(0,len(L)):
					if j == len(L)-1:
						s=s+L[j][i]
					else:
						s=s+L[j][i]+','
				s=s+'\n'

			s=s[0:len(s)-1]
			s=s.split('\n')
			# for i in s:
			# 	print i

			# #### removing duplicates ####
			D=set(s)
			ind=[]
			for i in D:
				ind.append(s.index(i))
			ind.sort()
			distinct_values=[]
			for i in ind:
				distinct_values.append(s[i])
			for i in distinct_values:
				print i





def aggregate(operation,projections,tables,cartesian_product,conditions):
	###################################################
	L=[]
	indices=[]
	temp = cartesian_product[0].split(',')
	if(len(projections)>len(temp)):
		print 'More attributes selected...'
	else:
		for j in projections:
			for i in xrange(0,len(temp)):
				if j == temp[i]:
					indices.append(i)
					break
		data=[]
		for i in cartesian_product[1::]:
			data.append(i.split(','))

		s=''
		for i in xrange(0,len(projections)):
			s=s+tables[0]+'.'+projections[i]
			if i != len(projections)-1:
				s=s+','
		s=s+'\n'
		for i in xrange(0,len(data)):
			for j in xrange(0,len(indices)):
				if j == len(indices)-1:
					s=s+data[i][indices[j]]
				else:
					s=s+data[i][indices[j]]+','
			s=s+'\n'
		# print s[0:len(s)-1]
		nums = s.split('\n')[1::]
		nums=nums[0:len(nums)-1]
		#print nums
		for i in xrange(0,len(nums)):
			nums[i] = float(nums[i])
	###################################################

	if conditions == '':
		if operation == 'max':
			print int(max(nums))
		elif operation == 'min':
			print int(min(nums))
		elif operation == "sum":
			print int(sum(nums))
		elif operation == 'avg':
			print sum(nums)/len(nums)
		else:
			print 'Invalid Operation...'


#distinct(operation,projections,tables,cartesian_product,conditions)
def distinct(operation,projections,tables,cartesian_product,conditions):
	if conditions == '':
		L=[]
		indices=[]
		temp = cartesian_product[0].split(',')
		attrib = projections

		if(len(projections)>len(temp)):
			print 'More attributes entered...'
			return
		else:
			for i in attrib:
				if i not in temp:
					print 'Wrong attributes entered...'
					return

			for j in projections:
				for i in xrange(0,len(temp)):
					if j == temp[i]:
						indices.append(i)
						break
			data=[]
			for i in cartesian_product[1::]:
				data.append(i.split(','))

			s=''
			for i in xrange(0,len(projections)):
				s=s+tables[0]+'.'+projections[i]
				if i != len(projections)-1:
					s=s+','
			s=s+'\n'
			for i in xrange(0,len(data)):
				for j in xrange(0,len(indices)):
					if j == len(indices)-1:
						s=s+data[i][indices[j]]
					else:
						s=s+data[i][indices[j]]+','
				s=s+'\n'
			s=s[0:len(s)-1]
			s=s.split('\n')


			#### removing duplicates ####
			D=set(s)
			ind=[]
			for i in D:
				ind.append(s.index(i))
			ind.sort()
			distinct_values=[]
			for i in ind:
				distinct_values.append(s[i])
			for i in distinct_values:
				print i



#				   <list>	   ['t1','t2'] <str> read()->str and readlines->list
def evaluate_query(projections,operation,tables,conditions):
	cartesian_product = []			 #list of strings - readlines()
	rel = open(tables[0]+'.csv','r').read().split()#.split(',\r\n')
	attributes = all_tables_indexed[tables[0]].values()
	s=''

	if len(tables) == 1:
		for i in xrange(0,len(attributes)):
			if i == len(attributes)-1:
				s=s+attributes[i]
			else:
				s=s+attributes[i]+','
	else:
		for i in xrange(0,len(attributes)):
			if i == len(attributes)-1:
				s=s+tables[0]+'.'+attributes[i]
			else:
				s=s+tables[0]+'.'+attributes[i]+','

	cartesian_product.append(s)
	cartesian_product.extend(rel)


	if len(tables)>1:
		for i in xrange(1,len(tables)):
			cartesian_product = cap(cartesian_product,tables[i])#.split(',\r\n'))

	if operation == 'select_all':
		select_all(tables,cartesian_product,conditions),
	elif operation in aggregate_functions:
		aggregate(operation,projections,tables,cartesian_product,conditions)
	elif operation == 'select':
		select(projections,tables,cartesian_product,conditions)
	elif operation == 'distinct':
		distinct(operation,projections,tables,cartesian_product,conditions)
	else:
		print 'Invalid operation...'


def main():
	file = open('metadata.txt','r')
	lines = file.readlines()

	#type of readlines = list
	#type of read = str

	### pre-processing metadata to map table names with their attributes###

	for i in xrange(0,len(lines)):
		k = 0
		if lines[i][0:13] == '<begin_table>':
			attributes = {}
			inverse_attributes={}
			for j in xrange(i+2,len(lines)):
				if lines[j][0:11] == '<end_table>':
					break
				else:
				#	attributes.append(lines[j][0:1])
					attributes[lines[j][0:1]] = k
					inverse_attributes[k]=lines[j][0:1]
				k+=1
			all_tables[lines[i+1][0:len(lines[i+1])-2]]=attributes
			all_tables_indexed[lines[i+1][0:len(lines[i+1])-2]]=inverse_attributes
			i=j+1
	######################################################################

	# all_tables = {'table1':['A','B','C'],'table2':['B','D']}
	# print all_tables

	#a list:
	queries = sqlparse.split(sys.argv[1])
	total_queries = len(queries)


	#print sqlparse.format(queries[0],reindent=True,keyword_case='upper')

	for i in xrange(0,total_queries):
		#a tuple:
		parsed_statement = sqlparse.parse(queries[i])# parsed[0] is statement object
		tokens_of_statement =  parsed_statement[0].tokens# type(token) = <class 'sqlparse.sql.Token'>
		total_tokens = len(tokens_of_statement)

		opn_on_attrib = ''
		condition = ''
		for j in xrange(0,total_tokens):
			current_token = str(tokens_of_statement[j])
			################################################
			###### fetching attributes and opn on them #####
			if current_token == 'select':
				next_token = str(tokens_of_statement[j+2])
	#			print 'next token = ',next_token
				
				if next_token == '*':
					opn_on_attrib = 'select_all'
					attributes_to_select = 'all'
				elif next_token[0:3] == 'max' or next_token[0:3] == 'min' or next_token[0:3] == 'avg' or next_token[0:3] == 'sum':
					opn_on_attrib = next_token[0:3]
					attributes_to_select = next_token[4].split(',')
				elif next_token[0:8] == 'distinct':
					opn_on_attrib = 'distinct'
					attributes_to_select = str(tokens_of_statement[j+4]).split(',')
				else:
					opn_on_attrib = 'select'
					attributes_to_select = next_token.split(',')
				j = j+4
	#			print 'attributes: ',attributes_to_select
			################################################
			################################################



			################################################
			############### fetching tables ################
			if current_token == 'from':
				tables_to_select = str(tokens_of_statement[j+2]).split(',')
	#			print 'tables = ',tables_to_select
				j = j+2
			################################################
			################################################

			if current_token[0:5] == 'where':
				condition = tokens_of_statement[-1]
	#			print tokens_of_statement[-1]

		evaluate_query(attributes_to_select,opn_on_attrib,tables_to_select,condition)

if __name__ == '__main__':
	try:
		main()
	except:
		print 'Error occured, please check your Query !'
